// CSC237:  "ReadTextFile" sample program 
//

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{

	string inputText = "";
	int inputLineLength = 0;
	string inputFileName;
	ifstream inputFile;

	// Input file:  prompt for filename, open file for input.
	cout << "Enter name of input file: ";
	cin >> inputFileName;
	inputFile.open(inputFileName.c_str());

	// Check for file open error.
	if (inputFile.fail())
	{
		cout << "(line " << __LINE__ << ") Error opening file:  "
			<< inputFileName << endl;
		
		exit(1);     // exit with error status.
	}

	while (getline(inputFile, inputText))
	{
		inputLineLength = inputText.length();
		cout << "Text: " << left << setw(80) << inputText
			<< " (Length=" << inputLineLength << ")" << endl;
	}

	inputFile.close();
	
	exit(0);     // exit with SUCCESS status.
}  // end "main" function



