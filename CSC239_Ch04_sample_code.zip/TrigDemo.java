/*
 * Demonstration of Trigonometric methods.
 */

/**
 *
 * @author Peter Morgan
 */
public class TrigDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double radians, sine, cosine, tangent;
        int degrees;

        System.out.printf("%15s %15s %15s %15s %15s %15s\n",
                "heading", "degrees", "radians", "sine", "cosine", "tangent");
        for (int heading = 0; heading < 360; heading += 1) {
            degrees = (-heading + 90);
            if (degrees <= -180) {
                degrees += 360;
            }
            radians = Math.toRadians(degrees);
            sine = Math.sin(radians);
            cosine = Math.cos(radians);
            tangent = Math.tan(radians);
            System.out.printf("%15d %15d %15.10f %15.10f %15.10f %15.10f\n",
                    heading, degrees, radians, sine, cosine, tangent);
        }
    } //( end main)

} // (end class TrigDemo)
