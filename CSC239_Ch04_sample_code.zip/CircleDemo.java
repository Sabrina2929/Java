
import java.io.IOException;
import java.util.Scanner;

/*
 * Demonstrate the use of the Circle class.
 */
public class CircleDemo {

    static String userInput;

    /*
     * Create two Circle objects, 
     * input parameters (radius, position of center).
     *
     */
    public static void main(String[] args)
            throws IOException {
        Scanner input = new Scanner(System.in);
        Circle circle1 = new Circle();
        Circle circle2 = new Circle();
        double distanceCenterToCenter;

        /*
         * Prompt the user to X, Y coordinates of the center, 
         * and also for the radius of circle1.
         */
        System.out.print("Please enter X1: ");
        userInput = input.nextLine();
        double xValue = Double.parseDouble(userInput);
        
        System.out.printf("xValue=%5.3f\n", xValue);
        circle1.setCenterX(xValue);
        System.out.print("Please enter Y1: ");
        userInput = input.nextLine();
        double yValue = Double.parseDouble(userInput);
        circle1.setCenterY(yValue);

        System.out.print("Please enter Radius 1: ");
        userInput = input.nextLine();
        double radius = Double.parseDouble(userInput);
        circle1.setRadius(radius);

        /*
         * Prompt the user to X, Y coordinates of the center, 
         * and also for the radius of circle2.
         */
        System.out.print("Please enter X2: ");
        userInput = input.nextLine();
        circle2.setCenterX(Double.parseDouble(userInput));

        System.out.print("Please enter Y2: ");
        userInput = input.nextLine();
        circle2.setCenterY(Double.parseDouble(userInput));

        System.out.print("Please enter Radius 2: ");
        userInput = input.nextLine();
        circle2.setRadius(Double.parseDouble(userInput));

        /* 
         * Output summary of circle paramters:
         */
        System.out.printf("Circle1: x=%5.2f, y=%5.2f, radius=%5.2f\n",
                circle1.getCenterX(),
                circle1.getCenterY(),
                circle1.getRadius());
        System.out.printf("Circle2: x=%5.2f, y=%5.2f, radius=%5.2f\n",
                circle2.getCenterX(),
                circle2.getCenterY(),
                circle2.getRadius());

        /*
         * Calculate center-to-center distance between circle1 and circle2:
         */
        distanceCenterToCenter = circle1.distance(circle2);

        System.out.printf("distance (center-to-center)=%5.2f\n",
                distanceCenterToCenter);

    }

} // (end class CircleDemo)

/**
 * A Circle object is represented by the X,Y coordinates of the center, plus the
 * radius.
 *
 */
class Circle {

    // Member variables
    private double centerX, centerY, radius;

    // Accessor and Mutator methods
    double getCenterX() {
        return centerX;
    }

    void setCenterX(double value) {
        centerX = value;
    }

    double getCenterY() {
        return centerY;
    }

    void setCenterY(double value) {
        centerY = value;
    }

    double getRadius() {
        return radius;
    }

    void setRadius(double value) {
        radius = value;
    }

    /**
     * Calculate the distance between the centers of two Circle objects.
     *
     * @param otherCircle = reference to the "other" circle object.
     * @return double value representing the center-to-center distance
     */
    double distance(Circle otherCircle) {
        double deltaX = Math.abs(centerX - otherCircle.getCenterX());
        double deltaY = Math.abs(centerY - otherCircle.getCenterY());
        double dist = Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
        return dist;
    }
} // (end class Circle)
