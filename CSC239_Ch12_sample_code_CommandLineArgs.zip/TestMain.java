
import java.io.*;
import java.util.*;

public class TestMain {

    public static void main(String[] args) throws Exception {
        System.out.printf("User entered %d "
        +"command-line argument(s):\n", args.length);
        for (int i=0; i<args.length; i++){
            System.out.printf("args[%d]=%s, len=%d\n",
            i, args[i], args[i].length());
        }
    }
}
