
import java.io.*;
import java.util.*;

public class AddLineNumbers {

    public static void main(String[] args) throws Exception {
        // Check command line parameter usage
        if (args.length != 2) {
            System.out.println(
                    "Usage: java AddLineNumbers sourceFile targetFile ");
            System.exit(1);
        }

        // Check if source file exists
        File sourceFile = new File(args[0]);
        if (!sourceFile.exists()) {
            System.out.println("Source file " + args[0] + " does not exist");
            System.exit(2);
        }

        // Check if target file exists
        File targetFile = new File(args[1]);
        if (targetFile.exists()) {
            System.out.println("Target file " + args[1] + " already exists");
            System.exit(3);
        }

        // Create input and output files
        Scanner input = new Scanner(sourceFile);
        PrintWriter output = new PrintWriter(targetFile);
        int lineNumber = 0;
        while (input.hasNext()) {
            String s1 = input.nextLine();   
            lineNumber++;
            String s2 = lineNumber+": "+s1;
            output.println(s2);
        }

        input.close();
        output.close();
    }
}
