// CSC239:    SimpleCalculator JavaFX sample program
//
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos; 
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class SimpleCalculator extends Application {

    Label lbNumber1, lbNumber2, lbResult;
    TextField tfNumber1, tfNumber2, tfResult;
    Button btAdd, btSubtract, btMultiply, btDivide;

    @Override
    // Override the start method in the Application class
    public void start(Stage primaryStage) {
        FlowPane pane = new FlowPane();
        pane.setPadding(new Insets(3));  // gap from edges of pane
        pane.setHgap(5);                 // horizontal gap between nodes
        pane.setVgap(5);                 // vertical gap between nodes
        pane.setStyle("-fx-border-color: green; -fx-border-width:3px");
        lbNumber1 = new Label("Number 1: ");
        lbNumber2 = new Label("Number 2: ");
        lbResult = new Label("Result: ");
        tfNumber1 = new TextField();
        tfNumber2 = new TextField();
        tfResult = new TextField();
        tfNumber1.setPrefColumnCount(3); // width of text fields
        tfNumber2.setPrefColumnCount(3);
        tfResult.setPrefColumnCount(12);
       
        pane.getChildren().addAll(lbNumber1, tfNumber1, lbNumber2, tfNumber2,
                lbResult, tfResult);

        // Create four buttons
        HBox hBox = new HBox(5);
        btAdd = new Button("Add");
        btSubtract = new Button("Subtract");
        btMultiply = new Button("Multiply");
        btDivide = new Button("Divide");
        hBox.setAlignment(Pos.CENTER);
        hBox.setStyle("-fx-border-color: red; -fx-border-width:3px");
        hBox.getChildren().addAll(btAdd, btSubtract, btMultiply, btDivide);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(pane);
        borderPane.setBottom(hBox);
        BorderPane.setAlignment(hBox, Pos.TOP_CENTER);

        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 300, 150);
        primaryStage.setTitle("Simple Calculator"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        btAdd.setOnAction(new ButtonHandler());

        btSubtract.setOnAction(new ButtonHandler());

        btMultiply.setOnAction(new ButtonHandler());

        btDivide.setOnAction(new ButtonHandler());
    }

    class ButtonHandler implements EventHandler<ActionEvent> {

        @Override
        // Convert the TextField objects to floating point numbers.
        // Perform the specific calculation.
        // Convert the result to a String and display it.
        public void handle(ActionEvent e) {
            double number1 = Double.parseDouble(tfNumber1.getText());
            double number2 = Double.parseDouble(tfNumber2.getText());
            double result=0.0;
            String resultText = null;
            if (e.getSource() == btAdd) {
                result = number1 + number2;
            } else if (e.getSource() == btSubtract) {
                result = number1 - number2;
            } else if (e.getSource() == btMultiply) {
                result = number1 * number2;
            } else if (e.getSource() == btDivide) {
                result = number1 / number2;
            }
            resultText = String.format("%11.5f", result);
            tfResult.setText(resultText);
        }
    }

    /**
     * The main method is only needed for the IDE with limited JavaFX support.
     * Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
