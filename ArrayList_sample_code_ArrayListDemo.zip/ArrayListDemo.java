// ArrayListDemo:  Create an ArrayList of SimplifiedWord objects.

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListDemo {
	private static ArrayList<SimplifiedWord> uniqueWordList;

	
	public static void main(String[] args) {
		uniqueWordList = new ArrayList<SimplifiedWord>();
		Scanner keyboardInput = new Scanner(System.in);
		Boolean keepRunning = true;
		
		while(keepRunning == true){
			System.out.print("Enter text: ");
			String inputText = keyboardInput.nextLine();
                        // Split the inputText string into individual words,
                        // while ignoring most punctuation characters.
			String[] words = inputText.split("\\W+");  
			for(int i=0;i<words.length;i++){
					recordNewOccurrence(words[i]);
			}
			printWordList(uniqueWordList);
			System.out.println("_______________________________");
		}
		keyboardInput.close();
		System.out.println("Exit program.");
	} // (end main)

	/**
	 * Print word list: use printf to format the output and
	 *                  call toString for each object in the list.
	 */
	public static void printWordList(ArrayList<SimplifiedWord> uniqueWordList) {
		System.out.println("ArrayList contents: ");
		for (int i = 0; i < uniqueWordList.size(); i++) {
			System.out.printf("%d: %s \n", i, uniqueWordList.get(i).toString());
		}

	}

/*____________________________________________________________________________
*        Record a new occurrence of the word contained in the wordText String:
*        If the new word is NOT already in the list, insert a new SimplifiedWord
*        object at the correct location in uniqueWordList so that all words 
*        are in alphabetical order.  
*        If this particular word has already been recorded in uniqueWordList, 
*        do NOT insert a duplicate.  Instead, call incrementOccurrenceCount() 
*        for the existing SimplifiedWord object.
*/
	static void recordNewOccurrence(String wordText) {
		SimplifiedWord candidate = new SimplifiedWord(wordText);

                // If the list was previously empty, then the new 
                // SimplifiedWord object will be the only member of the list.
		if (uniqueWordList.isEmpty()) {
			uniqueWordList.add(candidate);
		} else {
                // Search through the existing members of uniqueWordList, to
                // find the location where the new candidate word should be
                // inserted.  (Because the uniqueWordList is ALWAYS arranged
                // in alphabetical order, the new candidate word is 
                // "greater than" every word it finds in the list UNTIL it
                // reaches the correct location where it should be inserted.
			for (int i = 0; i < uniqueWordList.size(); i++) {
				int result = candidate.compareTo(uniqueWordList.get(i));
				if (result < 0) {
				    // If candidate is < current word in list, insert candidate here.
				       uniqueWordList.add(i, candidate);
				       return;
				} else if (result == 0) {
					// If candidate matches word in list, add a new Occurrence
					uniqueWordList.get(i).incrementOccurrenceCount();
					return;
				}
			}
			// If candidate is > last word in list, insert candidate at end of list.
			uniqueWordList.add(candidate);

			return;
		}
	}

} // (end class ArrayListDemo)

/*____________________________________________________________________________
 *     The SimplifiedWord class is somewhat similar to the LowercaseWord class
 *     in Project 3.
 */
class SimplifiedWord implements Comparable<SimplifiedWord> {

	private String lowerCaseText;        // Lowercase equivalent of the 
                                             // original word.
	private int occurrenceCount = 0;

/*________________________________________________________________________
*      Constructor for SimplifiedWord object containing specific text.
*/
	public SimplifiedWord(String wordText) {
		lowerCaseText = wordText.toLowerCase(); // force to lowercase
		occurrenceCount = 1;
	}

	public SimplifiedWord() {
		System.out.println("executing SimplifiedWord no-arg constructor.");
		lowerCaseText = "";
		occurrenceCount = 1;
	}

/*___________________________________________________________________________
*       Because the SimplifiedWord class implements the Comparable interface
*       with respect to another SimplifiedWord object, it MUST contain a 
*       method named "compareTo".
*       This method will return a zero if the two words match, and a negative
*       number if the "this" object is alphabetically greater than 
*       the "other" object.
*/
	@Override
	public int compareTo(SimplifiedWord other) {
		return this.getText().compareTo(other.getText());
	}

	public void incrementOccurrenceCount() {
		occurrenceCount++;
	}

	public String getText() {
		return lowerCaseText;
	}

/*_________________________________________________________________________
*       Convert the current object to a String
*/
	public String toString() {
		return (lowerCaseText + "(" + occurrenceCount + ")");
	}
} // (end class SimplifiedWord)


