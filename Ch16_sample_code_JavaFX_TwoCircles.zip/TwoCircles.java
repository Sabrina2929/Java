// This JavaFX application displays two
// Circle objects and indicates whether 
// the two Circle object intersect.
// The program allows the user to move
// either Circle object by the 
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class TwoCircles extends Application {

  private double paneWidth = 500;
  private double paneHeight = 500;

  private Label status = new Label("Two circles intersect? No");
  private Circle redCircle = new Circle(50, 50, 50);
  private Circle blueCircle = new Circle(160, 50, 50);

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {

    // The redData pane displays the numeric values
    // for the red Circle object.
    // Inside the redData pane is a GridPane object
    // named redData1.
    BorderPane redData = new BorderPane();
    redData.setStyle("-fx-border-color: red; -fx-border-width:3px");
    redData.setTop(new Label("Enter red circle info:"));
    GridPane redData1 = new GridPane();
    redData1.setHgap(5);
    redData1.add(new Label("Center x:"), 0, 0);
    redData1.add(new Label("Center y:"), 0, 1);
    redData1.add(new Label("Radius:"), 0, 2);

    TextField tfCenterX1 = new TextField("50");
    TextField tfCenterY1 = new TextField("50");
    TextField tfRadius1 = new TextField("50");
    redData1.add(tfCenterX1, 1, 0);
    redData1.add(tfCenterY1, 1, 1);
    redData1.add(tfRadius1, 1, 2);
    tfCenterX1.setPrefColumnCount(3);
    tfCenterY1.setPrefColumnCount(3);
    tfRadius1.setPrefColumnCount(3);
    tfCenterX1.setAlignment(Pos.BOTTOM_RIGHT);
    tfCenterY1.setAlignment(Pos.BOTTOM_RIGHT);
    tfRadius1.setAlignment(Pos.BOTTOM_RIGHT);
    redData.setCenter(redData1);

    // The blueData pane displays the numeric values
    // for the blue Circle object.
    // Inside the blueData pane is a GridPane object
    // named blueData1.
    BorderPane blueData = new BorderPane();
    blueData.setTop(new Label("Enter Blue circle info:"));
    blueData.setStyle("-fx-border-color: blue; -fx-border-width:3px");
    GridPane blueData1 = new GridPane();
    blueData1.setHgap(5);
    blueData1.add(new Label("Center x:"), 0, 0);
    blueData1.add(new Label("Center y:"), 0, 1);
    blueData1.add(new Label("Radius:"), 0, 2);

    TextField tfCenterX2 = new TextField("160");
    TextField tfCenterY2 = new TextField("50");
    TextField tfRadius2 = new TextField("50");
    tfCenterX2.setPrefColumnCount(3);
    tfCenterY2.setPrefColumnCount(3);
    tfRadius2.setPrefColumnCount(3);
    tfCenterX2.setAlignment(Pos.BOTTOM_RIGHT);
    tfCenterY2.setAlignment(Pos.BOTTOM_RIGHT);
    tfRadius2.setAlignment(Pos.BOTTOM_RIGHT);

    blueData1.add(tfCenterX2, 1, 0);
    blueData1.add(tfCenterY2, 1, 1);
    blueData1.add(tfRadius2, 1, 2);
    blueData.setCenter(blueData1);

    HBox hBox = new HBox(5);
    hBox.setStyle("-fx-border-color: green; -fx-border-width:3px");
    hBox.setAlignment(Pos.CENTER);
    hBox.getChildren().addAll(redData, blueData);

    // The pane object will hold both
    // paneForCircles and hBox panes: 
    BorderPane pane = new BorderPane();
    pane.setTop(status);
    BorderPane.setAlignment(status, Pos.CENTER);
    Pane paneForCircles = new Pane();
    
    redCircle.setFill(Color.RED);
    redCircle.setStroke(Color.BLACK);
    blueCircle.setFill(Color.BLUE);
    blueCircle.setStroke(Color.BLACK);

    paneForCircles.getChildren().addAll(redCircle, blueCircle);
    paneForCircles.setStyle("-fx-border-color: pink; -fx-border-width:3px");

    pane.setCenter(paneForCircles);
    pane.setBottom(hBox);

    //  bigPane is the Pane for the overall screen: 
    //  it holds the pane object in its center region,
    //  and the btRedraw object in its bottom region.
    BorderPane bigPane = new BorderPane();
    bigPane.setCenter(pane);
    bigPane.setStyle("-fx-border-color: purple; -fx-border-width:6px");
    Button btRedraw = new Button("Redraw Circles");
    bigPane.setBottom(btRedraw);
    BorderPane.setAlignment(btRedraw, Pos.CENTER);

    // Create a scene and place it in the stage
    Scene scene = new Scene(bigPane, paneWidth, paneHeight);
    primaryStage.setTitle("Two Circles"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    btRedraw.setOnAction(e -> {
      redCircle.setCenterX(Double.parseDouble(tfCenterX1.getText()));
      redCircle.setCenterY(Double.parseDouble(tfCenterY1.getText()));
      redCircle.setRadius(Double.parseDouble(tfRadius1.getText()));
      blueCircle.setCenterX(Double.parseDouble(tfCenterX2.getText()));
      blueCircle.setCenterY(Double.parseDouble(tfCenterY2.getText()));
      blueCircle.setRadius(Double.parseDouble(tfRadius2.getText()));

      updateStatus();
    });

    redCircle.setOnMouseDragged(e -> {
      if (redCircle.contains(e.getX(), e.getY())) {
        redCircle.setCenterX(e.getX());
        redCircle.setCenterY(e.getY());
        tfCenterX1.setText(e.getX() + "");
        tfCenterY1.setText(e.getY() + "");
        updateStatus();
      } 
    });
            
    blueCircle.setOnMouseDragged(e -> {
      if (blueCircle.contains(e.getX(), e.getY())) {
        blueCircle.setCenterX(e.getX());
        blueCircle.setCenterY(e.getY());
        tfCenterX2.setText(e.getX() + "");
        tfCenterY2.setText(e.getY() + "");
        updateStatus();
      }
    });
  }

  // Determine whether the two Circle objects intersect
  // by comparing the sum of the radius values with the
  // distance between the two centers.
  private void updateStatus() {
    // Calculate distance (center-to-center)
    double xDiff = redCircle.getCenterX()-blueCircle.getCenterX();
    double yDiff = redCircle.getCenterY()-blueCircle.getCenterY();
    double distance = Math.sqrt(xDiff*xDiff + yDiff*yDiff);

    if (distance <= redCircle.getRadius() + blueCircle.getRadius()) {
      status.setText("Two circles intersect? Yes");
    } else {
      status.setText("Two circles intersect? No");
    }
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
