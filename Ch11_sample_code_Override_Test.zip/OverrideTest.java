/*
 * Liang:   Section 11.5   -- Overriding vs. Overloading
 */

public class OverrideTest {

    public static void main(String[] args) {
        A a = new A();
        a.p(10);
        a.p(10.0);
        //a.q(30);
    }

}

class B {

    public void p(double i) {
        System.out.println(i * 2);
    }

    public void q(double i) {
        System.out.println(i * 2);
    }
}

class A extends B {

    // This method OVERRIDES the method in class B

    public void p(double i) {
        System.out.println(i);
    }
}
