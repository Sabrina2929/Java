// This JavaFX sample program displays a Circle
// at a fixed location, and responds to mouse 
// movement by displaying (and modifying) a 
// Text object.   The text indicates whether 
// the lower-left corner of the Text object 
// is "inside" or "outside" the Circle.

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class InsideACircle extends Application {  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {     
    Pane pane = new Pane();
    Circle circle = new Circle(100, 60, 50);
    circle.setFill(Color.WHITE);
    circle.setStroke(Color.BLACK);
    Text text = new Text();
    pane.getChildren().addAll(circle, text);
    
    // Whenever the mouse is moved, check if the
    // new mouse position is inside or outside
    // the Circle object.
    pane.setOnMouseMoved(e -> { 
      String location = null;
      if (circle.contains(e.getX(), e.getY())) {
        location = "inside"; 
      }
      else {
        location = "outside";
      }
  // Create the text for display, and position the 
  // Text object at the mouse coordinates.
      text.setText(String.format(".(%5.0f, %5.0f) is %s the circle", 
                        e.getX(), e.getY(), location));
      text.setX(e.getX());
      text.setY(e.getY());
    });

    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, 400, 250);
    primaryStage.setTitle("Inside A Circle"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
} 
