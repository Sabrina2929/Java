// CSC239:   Compute Factorial
//           This is the sample code for Listing 18.1 in the textbook,
//           with some additional print statements added to illustrate
//           the recursive processing.

import java.util.Scanner;

public class ComputeFactorial {

    /**
     * Main method
     */
    public static void main(String[] args) {
        // Create a Scanner
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a non-negative integer: ");
        int n = input.nextInt();

        // Display factorial
        System.out.println("Factorial of " + n + " is " + factorial(n));
    }

    /**
     * Return the factorial for a specified number
     */
    public static long factorial(int n) {
        long temp = 0;
        System.out.printf("Enter with n=%d\n", n);
        if (n == 0) // Base case
        {
            System.out.printf("BASE CASE: n=%d\n", n);
            return 1;
        } else {
            temp = factorial(n - 1);
            System.out.printf("n=%d, temp=%d\n", n, temp);
            return n * temp; // Recursive call3
        }
    }
}
