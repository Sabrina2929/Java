
import java.util.Scanner;

public class ComputeFibonacci {

    /**
     * Main method
     */
    public static void main(String[] args) {
        // Create a Scanner
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an index for a Fibonacci number: ");
        int index = input.nextInt();

        // Find and display the Fibonacci number
        System.out.println("The Fibonacci number at index "
                + index + " is " + fib(index));
    }

    /**
     * The method for finding the Fibonacci number
     */
    public static long fib(long index) {
        System.out.println("Enter fib, index=" + index);
        if (index == 0) // Base case
        {
            return 0;
        } else if (index == 1) // Base case
        {
            return 1;
        } else // Reduction and recursive calls
        {
            //   return fib(index - 1) + fib(index - 2);
            long fib1;
            System.out.println("Calculating fib1 for " + (index - 1));
            fib1 = fib(index - 1);

            long fib2;
            System.out.println("Calculating fib2 for " + (index - 2));
            fib2 = fib(index - 2);
            System.out.printf("Returning: index=%d, fib1=%d, fib2=%d\n",
                    index, fib1, fib2);
            return fib1 + fib2;

        }
    }
}
