// Demonstration of System.out.printf() for floating point numbers

import java.util.Scanner;

public class PrintfDemo {

    public static void main(String[] args) {
        // Create a Scanner
        Scanner input = new Scanner(System.in);

        //    (deliberate endless loop)
        while (true) {
            // Input two floating point numbers
            System.out.print("Enter number1 (floating point): ");
            double number1 = input.nextDouble();

            System.out.print("Enter number2 (floating point): ");
            double number2 = input.nextDouble();

            // Subtract number2 from number1 5 times
            double number3 = (number1 - number2 - number2 - number2 - number2 - number2);

            System.out.print("print number1=" + number1);
            System.out.print(" number2=" + number2);
            System.out.print(" number3=" + number3);
            System.out.println();
            System.out.printf("printf number1=%f, number2=%f, number3=%12.2f\n",
                    number1, number2, number3);
        } // (end while)
    } // (end main)
} // (end class PrintfDemo)
