//               Constructor-chaining Example:
//   An object of the Faculty class IS an object of the Employee class.
//   An object of the Employee class IS an object of the Person class.

class Person {

    public Person() {
        System.out.println("(1) Person's no-arg constructor is invoked");
    }
}

class Employee extends Person {
//   The Employee no-arg constructor explicitly invokes the Employee constructor
//   that takes a String parameter, this("  . . .   ")
//   before completing its own execution.
    public Employee() {
        this("(2) Invoke Employee’s overloaded constructor");
        System.out.println("(3) Employee's no-arg constructor is invoked");
    }

 //   The Employee constructor with String parameter calls Person no-arg
 //   constructor BEFORE printing the String s.
    public Employee(String s) {
        super();
        System.out.println(s);
    }
}

public class Faculty extends Employee {

    public static void main(String[] args) {
       new Faculty();
    }

    //   Faculty no-arg constructor explicitly invokes the Employee no-arg constructor,
    //   before printing string.
public Faculty() {
        super();           // Invoke no-arg constructor of Employee.
        System.out.println("(4) Faculty's no-arg constructor is invoked");
    }
}
